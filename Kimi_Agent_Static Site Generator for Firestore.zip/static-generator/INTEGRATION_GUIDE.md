# Integration Guide

## आपकी मौजूदा वेबसाइट में Static Generator Integrate करना

### Step 1: Files Copy करें

अपनी मौजूदा website के root folder में ये files/folders copy करें:

```
static-generator/
├── scripts/              →  आपकी website के root में copy करें
├── templates/            →  आपकी website के root में copy करें
├── src/                  →  आपकी website के root में copy करें
├── functions/            →  आपकी website के root में copy करें (Firebase Functions के लिए)
├── public/css/           →  आपकी existing public/css में merge करें
├── public/js/            →  आपकी existing public/js में merge करें
├── package.json          →  Merge करें (नीचे देखें)
├── vercel.json           →  Root में copy करें
└── .env.example          →  Root में copy करें
```

### Step 2: package.json Merge करें

आपकी existing `package.json` में ये scripts और dependencies add करें:

```json
{
  "scripts": {
    "generate": "node scripts/generate.js",
    "publish": "node scripts/publish.js",
    "deploy": "npm run generate && npm run publish",
    "serve": "npx serve public"
  },
  "dependencies": {
    "firebase-admin": "^12.0.0",
    "handlebars": "^4.7.8",
    "fs-extra": "^11.2.0",
    "simple-git": "^3.22.0",
    "dotenv": "^16.4.5",
    "chalk": "^4.1.2"
  }
}
```

### Step 3: Firebase Setup

1. **Service Account Key Download करें:**
   - Firebase Console → Project Settings → Service Accounts
   - "Generate New Private Key" पर click करें
   - Download की गई file को `serviceAccountKey.json` के नाम से root में save करें

2. **Environment Variables (Optional):**
   ```bash
   cp .env.example .env
   # .env file edit करें
   ```

### Step 4: Dependencies Install करें

```bash
npm install
```

### Step 5: Admin Panel में "Publish Website" Button Add करें

आपकी admin panel के React component में:

```jsx
import React, { useState } from 'react';

function PublishButton() {
  const [publishing, setPublishing] = useState(false);
  const [message, setMessage] = useState('');

  const handlePublish = async () => {
    setPublishing(true);
    setMessage('Publishing...');
    
    try {
      // Option 1: Using Firebase Callable Function
      const regenerateSite = firebase.functions().httpsCallable('triggerRegeneration');
      const result = await regenerateSite();
      
      // Option 2: Using HTTP API
      // const response = await fetch('/api/publish', { method: 'POST' });
      // const result = await response.json();
      
      setMessage('Website published successfully!');
    } catch (error) {
      setMessage('Error: ' + error.message);
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div>
      <button 
        onClick={handlePublish} 
        disabled={publishing}
        className="publish-btn"
      >
        {publishing ? 'Publishing...' : '🚀 Publish Website'}
      </button>
      {message && <p>{message}</p>}
    </div>
  );
}

export default PublishButton;
```

### Step 6: Firebase Functions Deploy करें (Optional - Auto-regeneration के लिए)

```bash
cd functions
npm install
firebase login
firebase deploy --only functions
```

### Step 7: Test करें

```bash
# Generate static files
npm run generate

# Local preview
npm run serve
```

### Step 8: Vercel Configuration

`vercel.json` already created है। बस ensure करें कि ये आपकी root में है।

## 🔥 Firestore Triggers Setup (Auto-Regeneration)

### Option A: Cloud Functions (Recommended)

Functions already `functions/index.js` में हैं। बस deploy करें:

```bash
firebase deploy --only functions
```

### Option B: Admin Panel से Manual Trigger

Admin panel में "Publish Website" button click करने से:
1. सारे static pages regenerate होंगे
2. GitHub पर commit/push होगा
3. Vercel पर auto-deploy होगा

## 📁 File Structure After Integration

```
your-website/
├── src/                      # आपकी existing React/Vite app
├── public/                   # Static files output
│   ├── css/
│   ├── js/
│   ├── jobs/                 # Generated job pages
│   ├── results/              # Generated result pages
│   ├── admit-card/           # Generated admit card pages
│   ├── index.html            # Generated homepage
│   ├── sitemap.xml
│   └── robots.txt
├── scripts/
│   ├── generate.js           # Main generator
│   ├── publish.js            # GitHub publisher
│   └── admin-publish.js      # Admin API
├── templates/                # HTML templates
├── functions/                # Firebase Cloud Functions
├── package.json              # Updated with new scripts
├── vercel.json               # Vercel config
└── serviceAccountKey.json    # Firebase credentials
```

## ⚙️ How It Works

### Data Flow:

```
Admin Panel → Firestore → Generate Script → Static HTML → GitHub → Vercel
```

1. **Admin** new job/result/admit card create करता है
2. **Firestore** में data save होता है
3. **"Publish Website"** button click होता है
4. **generate.js** Firestore से data fetch करता है
5. **Handlebars templates** से HTML generate होता है
6. **public/** folder में files save होती हैं
7. **publish.js** GitHub पर commit/push करता है
8. **Vercel** auto-deploy करता है

### User Request Flow:

```
User → Vercel CDN → Static HTML (No Firebase calls!)
```

## 🎨 Customization

### Existing Design Preserve करना

1. **CSS:** आपकी existing CSS files को `public/css/` में copy करें
2. **Templates:** `templates/partials/head.hbs` में अपनी CSS links add करें
3. **Layout:** `templates/partials/header.hbs` और `footer.hbs` में अपना layout add करें

### Colors/Fonts बदलना

`public/css/main.css` में CSS variables edit करें:

```css
:root {
  --primary-color: #your-color;
  --font-family: 'Your Font', sans-serif;
}
```

## 🚨 Important Notes

### ✅ DO:
- `serviceAccountKey.json` को कभी GitHub पर push न करें (already in .gitignore)
- `.env` file को कभी GitHub पर push न करें
- Regular testing करें `npm run generate` से
- Backup रखें अपने Firestore data का

### ❌ DON'T:
- Frontend से Firebase SDK हटाएं (admin panel के लिए चाहिए)
- `public/` folder में manually files edit न करें (generate से overwrite होंगी)
- Large images को repo में add न करें (external hosting use करें)

## 🐛 Common Issues

### Issue 1: "Firebase service account not found"

**Solution:**
```bash
# Check करें file exists
ls serviceAccountKey.json

# या environment variable set करें
export FIREBASE_SERVICE_ACCOUNT='{"type":"service_account",...}'
```

### Issue 2: "Cannot find module 'handlebars'"

**Solution:**
```bash
npm install
```

### Issue 3: Git push fail

**Solution:**
```bash
# Remote URL set करें
git remote add origin https://github.com/username/repo.git

# या HTTPS से SSH switch करें
git remote set-url origin git@github.com:username/repo.git
```

### Issue 4: Templates not found

**Solution:**
```bash
# Check folder structure
ls templates/
ls templates/partials/
ls templates/pages/
```

## 📞 Need Help?

1. Logs check करें: `npm run generate 2>&1 | tee logs.txt`
2. Firebase Console में errors check करें
3. `README.md` में detailed documentation पढ़ें

---

**Ready to go!** 🚀

अब आपकी website पूरी तरह से static होगी और zero Firebase reads के साथ काम करेगी!
