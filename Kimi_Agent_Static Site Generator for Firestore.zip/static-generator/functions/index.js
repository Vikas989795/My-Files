/**
 * Firebase Cloud Functions for Sarkari Sewayojan
 * Firestore triggers for automatic static site regeneration
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { exec } = require('child_process');
const util = require('util');
const path = require('path');

const execPromise = util.promisify(exec);

// Initialize Firebase Admin
admin.initializeApp();

const db = admin.firestore();

/**
 * Trigger: When a job is created
 */
exports.onJobCreate = functions.firestore
  .document('jobs/{jobId}')
  .onCreate(async (snap, context) => {
    const job = snap.data();
    console.log(`Job created: ${job.title} (ID: ${context.params.jobId})`);
    
    // Log the activity
    await logActivity('job_created', {
      jobId: context.params.jobId,
      title: job.title,
      slug: job.slug,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    // Optional: Trigger immediate regeneration
    // await triggerRegeneration('job', 'create', context.params.jobId);
    
    return null;
  });

/**
 * Trigger: When a job is updated
 */
exports.onJobUpdate = functions.firestore
  .document('jobs/{jobId}')
  .onUpdate(async (change, context) => {
    const newData = change.after.data();
    const oldData = change.before.data();
    
    console.log(`Job updated: ${newData.title} (ID: ${context.params.jobId})`);
    
    // Log the activity
    await logActivity('job_updated', {
      jobId: context.params.jobId,
      title: newData.title,
      slug: newData.slug,
      changes: getChanges(oldData, newData),
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return null;
  });

/**
 * Trigger: When a job is deleted
 */
exports.onJobDelete = functions.firestore
  .document('jobs/{jobId}')
  .onDelete(async (snap, context) => {
    const job = snap.data();
    console.log(`Job deleted: ${job.title} (ID: ${context.params.jobId})`);
    
    // Log the activity
    await logActivity('job_deleted', {
      jobId: context.params.jobId,
      title: job.title,
      slug: job.slug,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return null;
  });

/**
 * Trigger: When a result is created
 */
exports.onResultCreate = functions.firestore
  .document('results/{resultId}')
  .onCreate(async (snap, context) => {
    const result = snap.data();
    console.log(`Result created: ${result.title} (ID: ${context.params.resultId})`);
    
    await logActivity('result_created', {
      resultId: context.params.resultId,
      title: result.title,
      slug: result.slug,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return null;
  });

/**
 * Trigger: When a result is updated
 */
exports.onResultUpdate = functions.firestore
  .document('results/{resultId}')
  .onUpdate(async (change, context) => {
    const newData = change.after.data();
    const oldData = change.before.data();
    
    console.log(`Result updated: ${newData.title} (ID: ${context.params.resultId})`);
    
    await logActivity('result_updated', {
      resultId: context.params.resultId,
      title: newData.title,
      slug: newData.slug,
      changes: getChanges(oldData, newData),
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return null;
  });

/**
 * Trigger: When a result is deleted
 */
exports.onResultDelete = functions.firestore
  .document('results/{resultId}')
  .onDelete(async (snap, context) => {
    const result = snap.data();
    console.log(`Result deleted: ${result.title} (ID: ${context.params.resultId})`);
    
    await logActivity('result_deleted', {
      resultId: context.params.resultId,
      title: result.title,
      slug: result.slug,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return null;
  });

/**
 * Trigger: When an admit card is created
 */
exports.onAdmitCardCreate = functions.firestore
  .document('admitCards/{admitCardId}')
  .onCreate(async (snap, context) => {
    const admitCard = snap.data();
    console.log(`Admit card created: ${admitCard.title} (ID: ${context.params.admitCardId})`);
    
    await logActivity('admitCard_created', {
      admitCardId: context.params.admitCardId,
      title: admitCard.title,
      slug: admitCard.slug,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return null;
  });

/**
 * Trigger: When an admit card is updated
 */
exports.onAdmitCardUpdate = functions.firestore
  .document('admitCards/{admitCardId}')
  .onUpdate(async (change, context) => {
    const newData = change.after.data();
    const oldData = change.before.data();
    
    console.log(`Admit card updated: ${newData.title} (ID: ${context.params.admitCardId})`);
    
    await logActivity('admitCard_updated', {
      admitCardId: context.params.admitCardId,
      title: newData.title,
      slug: newData.slug,
      changes: getChanges(oldData, newData),
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return null;
  });

/**
 * Trigger: When an admit card is deleted
 */
exports.onAdmitCardDelete = functions.firestore
  .document('admitCards/{admitCardId}')
  .onDelete(async (snap, context) => {
    const admitCard = snap.data();
    console.log(`Admit card deleted: ${admitCard.title} (ID: ${context.params.admitCardId})`);
    
    await logActivity('admitCard_deleted', {
      admitCardId: context.params.admitCardId,
      title: admitCard.title,
      slug: admitCard.slug,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return null;
  });

/**
 * HTTP Function: Manual trigger for regeneration
 * Can be called from admin panel
 */
exports.regenerateSite = functions.https.onRequest(async (req, res) => {
  // Verify authentication (optional)
  const authHeader = req.headers.authorization;
  const apiKey = req.headers['x-api-key'];
  
  // Check API key if configured
  const expectedApiKey = functions.config().sitegenerator?.api_key;
  if (expectedApiKey && apiKey !== expectedApiKey) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  try {
    console.log('Starting site regeneration...');
    
    // Log start
    await logActivity('regeneration_started', {
      triggeredBy: req.body?.userId || 'manual',
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    // Run the generator script
    const scriptPath = path.join(__dirname, '../scripts/generate.js');
    const { stdout, stderr } = await execPromise(`node ${scriptPath}`);
    
    console.log('Generator output:', stdout);
    if (stderr) console.error('Generator errors:', stderr);
    
    // Log completion
    await logActivity('regeneration_completed', {
      triggeredBy: req.body?.userId || 'manual',
      output: stdout,
      errors: stderr || null,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    res.json({
      success: true,
      message: 'Site regenerated successfully',
      output: stdout
    });
    
  } catch (error) {
    console.error('Regeneration failed:', error);
    
    // Log failure
    await logActivity('regeneration_failed', {
      triggeredBy: req.body?.userId || 'manual',
      error: error.message,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * HTTP Function: Get regeneration status
 */
exports.getRegenerationStatus = functions.https.onRequest(async (req, res) => {
  try {
    const logsRef = db.collection('activityLogs')
      .orderBy('timestamp', 'desc')
      .limit(10);
    
    const snapshot = await logsRef.get();
    const logs = [];
    
    snapshot.forEach(doc => {
      logs.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    res.json({
      success: true,
      recentActivity: logs
    });
    
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * Scheduled Function: Daily regeneration at 3 AM
 */
exports.scheduledRegeneration = functions.pubsub
  .schedule('0 3 * * *')
  .timeZone('Asia/Kolkata')
  .onRun(async (context) => {
    console.log('Running scheduled site regeneration...');
    
    try {
      const scriptPath = path.join(__dirname, '../scripts/generate.js');
      const { stdout, stderr } = await execPromise(`node ${scriptPath}`);
      
      console.log('Scheduled regeneration completed:', stdout);
      
      await logActivity('scheduled_regeneration_completed', {
        output: stdout,
        errors: stderr || null,
        timestamp: admin.firestore.FieldValue.serverTimestamp()
      });
      
    } catch (error) {
      console.error('Scheduled regeneration failed:', error);
      
      await logActivity('scheduled_regeneration_failed', {
        error: error.message,
        timestamp: admin.firestore.FieldValue.serverTimestamp()
      });
    }
    
    return null;
  });

/**
 * Helper: Log activity to Firestore
 */
async function logActivity(type, data) {
  try {
    await db.collection('activityLogs').add({
      type,
      ...data
    });
  } catch (error) {
    console.error('Failed to log activity:', error);
  }
}

/**
 * Helper: Get changes between two objects
 */
function getChanges(oldObj, newObj) {
  const changes = {};
  
  for (const key in newObj) {
    if (JSON.stringify(oldObj[key]) !== JSON.stringify(newObj[key])) {
      changes[key] = {
        old: oldObj[key],
        new: newObj[key]
      };
    }
  }
  
  return changes;
}

/**
 * Callable Function: Trigger regeneration from client
 */
exports.triggerRegeneration = functions.https.onCall(async (data, context) => {
  // Verify user is authenticated
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }
  
  // Check if user is admin (optional)
  // const userDoc = await db.collection('users').doc(context.auth.uid).get();
  // if (!userDoc.exists || !userDoc.data().isAdmin) {
  //   throw new functions.https.HttpsError('permission-denied', 'Admin access required');
  // }
  
  try {
    console.log(`Regeneration triggered by user: ${context.auth.uid}`);
    
    await logActivity('regeneration_triggered', {
      userId: context.auth.uid,
      userEmail: context.auth.token.email,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    const scriptPath = path.join(__dirname, '../scripts/generate.js');
    const { stdout, stderr } = await execPromise(`node ${scriptPath}`);
    
    await logActivity('regeneration_completed', {
      userId: context.auth.uid,
      output: stdout,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    return {
      success: true,
      message: 'Site regenerated successfully',
      output: stdout
    };
    
  } catch (error) {
    console.error('Regeneration failed:', error);
    
    await logActivity('regeneration_failed', {
      userId: context.auth.uid,
      error: error.message,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    throw new functions.https.HttpsError('internal', error.message);
  }
});
