/**
 * Admin Panel Integration Script
 * 
 * This script provides the backend API for the "Publish Website" button
 * in the admin panel. It can be called via HTTP request or integrated
 * directly into the admin panel backend.
 * 
 * Usage:
 * 1. HTTP API: POST /api/publish
 * 2. Direct: require('./admin-publish').publishWebsite()
 */

const generate = require('./generate');
const publish = require('./publish');
const chalk = require('chalk');

/**
 * Main publish function
 * Generates static files and pushes to GitHub
 */
async function publishWebsite(options = {}) {
  const startTime = Date.now();
  
  console.log(chalk.cyan('========================================'));
  console.log(chalk.cyan('  Publishing Website...'));
  console.log(chalk.cyan('========================================\n'));
  
  const results = {
    success: false,
    generation: null,
    publish: null,
    duration: 0,
    errors: []
  };
  
  try {
    // Step 1: Generate static files
    console.log(chalk.blue('Step 1: Generating static files...'));
    results.generation = await generate();
    
    if (!results.generation.success) {
      throw new Error(`Generation failed: ${results.generation.error}`);
    }
    
    console.log(chalk.green('✓ Generation completed\n'));
    
    // Step 2: Publish to GitHub (if not skipped)
    if (!options.skipPublish) {
      console.log(chalk.blue('Step 2: Publishing to GitHub...'));
      results.publish = await publish();
      
      if (!results.publish.success) {
        console.log(chalk.yellow('⚠ Publish had issues but continuing...'));
        results.errors.push(results.publish.error);
      } else {
        console.log(chalk.green('✓ Publish completed\n'));
      }
    }
    
    results.success = true;
    results.duration = ((Date.now() - startTime) / 1000).toFixed(2);
    
    console.log(chalk.cyan('========================================'));
    console.log(chalk.green('  Website Published Successfully!'));
    console.log(chalk.cyan('========================================'));
    console.log(chalk.white(`Duration: ${results.duration}s`));
    
    if (results.generation.stats) {
      console.log(chalk.white(`Pages Generated:`));
      console.log(chalk.white(`  - Jobs: ${results.generation.stats.jobs}`));
      console.log(chalk.white(`  - Results: ${results.generation.stats.results}`));
      console.log(chalk.white(`  - Admit Cards: ${results.generation.stats.admitCards}`));
    }
    
    return results;
    
  } catch (error) {
    results.duration = ((Date.now() - startTime) / 1000).toFixed(2);
    results.errors.push(error.message);
    
    console.error(chalk.red('\n✗ Publish failed:'));
    console.error(chalk.red(error.message));
    
    return results;
  }
}

/**
 * Express.js route handler
 * For integrating with admin panel backend
 */
function createPublishRoute() {
  return async (req, res) => {
    // Verify authentication (implement as needed)
    // const token = req.headers.authorization;
    // if (!isValidToken(token)) {
    //   return res.status(401).json({ error: 'Unauthorized' });
    // }
    
    try {
      const results = await publishWebsite(req.body);
      
      if (results.success) {
        res.json({
          success: true,
          message: 'Website published successfully',
          data: results
        });
      } else {
        res.status(500).json({
          success: false,
          message: 'Publish failed',
          errors: results.errors
        });
      }
      
    } catch (error) {
      res.status(500).json({
        success: false,
        message: error.message
      });
    }
  };
}

/**
 * Simple HTTP server for standalone API
 */
function startAPIServer(port = 3001) {
  const http = require('http');
  const url = require('url');
  
  const server = http.createServer(async (req, res) => {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }
    
    const parsedUrl = url.parse(req.url, true);
    
    if (parsedUrl.pathname === '/api/publish' && req.method === 'POST') {
      const routeHandler = createPublishRoute();
      
      // Mock req.body
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          req.body = body ? JSON.parse(body) : {};
        } catch {
          req.body = {};
        }
        routeHandler(req, res);
      });
      
    } else if (parsedUrl.pathname === '/api/status' && req.method === 'GET') {
      res.json({
        status: 'ok',
        timestamp: new Date().toISOString()
      });
      
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not found' }));
    }
  });
  
  server.listen(port, () => {
    console.log(chalk.green(`Publish API server running on port ${port}`));
    console.log(chalk.blue(`POST http://localhost:${port}/api/publish`));
  });
  
  return server;
}

// Run if called directly
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.includes('--server')) {
    // Start API server
    const port = args.find(arg => arg.startsWith('--port='))?.split('=')[1] || 3001;
    startAPIServer(parseInt(port));
  } else {
    // Run publish directly
    publishWebsite().then(results => {
      process.exit(results.success ? 0 : 1);
    });
  }
}

module.exports = {
  publishWebsite,
  createPublishRoute,
  startAPIServer
};
