#!/usr/bin/env node

/**
 * Publish Script for Sarkari Sewayojan
 * Commits generated static files to GitHub and triggers deployment
 * 
 * Usage: node scripts/publish.js
 */

const fs = require('fs-extra');
const path = require('path');
const simpleGit = require('simple-git');
const chalk = require('chalk');
require('dotenv').config();

const CONFIG = {
  publicDir: path.join(__dirname, '../public'),
  gitRemote: process.env.GIT_REMOTE_URL || '',
  branch: process.env.DEPLOY_BRANCH || 'main',
  commitMessage: process.env.COMMIT_MESSAGE || 'Update static site content'
};

async function publish() {
  console.log(chalk.cyan('========================================'));
  console.log(chalk.cyan('  Sarkari Sewayojan - Publish Script'));
  console.log(chalk.cyan('========================================\n'));
  
  try {
    // Check if public directory exists
    if (!await fs.pathExists(CONFIG.publicDir)) {
      throw new Error('Public directory does not exist. Run generate first.');
    }
    
    // Initialize git
    const git = simpleGit(path.join(__dirname, '..'));
    
    // Check if git is initialized
    const isRepo = await git.checkIsRepo();
    if (!isRepo) {
      console.log(chalk.yellow('Git repository not initialized. Initializing...'));
      await git.init();
    }
    
    // Check git status
    const status = await git.status();
    console.log(chalk.blue('Git Status:'));
    console.log(chalk.white(`  Branch: ${status.current}`));
    console.log(chalk.white(`  Modified: ${status.modified.length}`));
    console.log(chalk.white(`  Created: ${status.created.length}`));
    console.log(chalk.white(`  Deleted: ${status.deleted.length}`));
    
    if (status.modified.length === 0 && status.created.length === 0 && status.deleted.length === 0) {
      console.log(chalk.yellow('\nNo changes to commit.'));
      return { success: true, message: 'No changes' };
    }
    
    // Add all changes in public directory
    console.log(chalk.blue('\nAdding files to git...'));
    await git.add('public/');
    console.log(chalk.green('✓ Files added'));
    
    // Commit changes
    console.log(chalk.blue('Committing changes...'));
    const commitResult = await git.commit(CONFIG.commitMessage);
    console.log(chalk.green(`✓ Committed: ${commitResult.commit}`));
    
    // Push if remote is configured
    const remotes = await git.getRemotes(true);
    if (remotes.length > 0 || CONFIG.gitRemote) {
      console.log(chalk.blue('Pushing to remote...'));
      
      if (CONFIG.gitRemote && !remotes.find(r => r.name === 'origin')) {
        await git.addRemote('origin', CONFIG.gitRemote);
      }
      
      await git.push('origin', CONFIG.branch);
      console.log(chalk.green('✓ Pushed to remote'));
    } else {
      console.log(chalk.yellow('⚠ No remote configured. Skipping push.'));
    }
    
    console.log(chalk.cyan('\n========================================'));
    console.log(chalk.green('  Publish Complete!'));
    console.log(chalk.cyan('========================================'));
    
    return {
      success: true,
      commit: commitResult.commit
    };
    
  } catch (error) {
    console.error(chalk.red('\n✗ Publish failed:'));
    console.error(chalk.red(error.message));
    
    return {
      success: false,
      error: error.message
    };
  }
}

// Run if called directly
if (require.main === module) {
  publish().then(result => {
    process.exit(result.success ? 0 : 1);
  });
}

module.exports = publish;
