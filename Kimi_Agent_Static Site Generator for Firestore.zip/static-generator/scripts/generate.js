#!/usr/bin/env node

/**
 * Static Site Generator for Sarkari Sewayojan
 * Fetches data from Firebase Firestore and generates static HTML pages
 * 
 * Usage: node scripts/generate.js
 */

const fs = require('fs-extra');
const path = require('path');
const Handlebars = require('handlebars');
const chalk = require('chalk');
require('dotenv').config();

// Import utilities
const DataFetcher = require('../src/utils/dataFetcher');

// Configuration
const CONFIG = {
  publicDir: path.join(__dirname, '../public'),
  templatesDir: path.join(__dirname, '../templates'),
  partialsDir: path.join(__dirname, '../templates/partials'),
  pagesDir: path.join(__dirname, '../templates/pages'),
  itemsPerPage: 20
};

// Register Handlebars helpers
function registerHelpers() {
  // Format date
  Handlebars.registerHelper('formatDate', function(date) {
    if (!date) return '';
    const d = new Date(date);
    if (isNaN(d.getTime())) return date;
    return d.toLocaleDateString('hi-IN', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });
  });

  // Truncate text
  Handlebars.registerHelper('truncate', function(text, length) {
    if (!text) return '';
    if (text.length <= length) return text;
    return text.substring(0, length).trim() + '...';
  });

  // Limit array
  Handlebars.registerHelper('limit', function(arr, limit) {
    if (!Array.isArray(arr)) return [];
    return arr.slice(0, limit);
  });

  // Equality check
  Handlebars.registerHelper('eq', function(a, b) {
    return a === b;
  });

  // Concat strings
  Handlebars.registerHelper('concat', function(...args) {
    return args.slice(0, -1).join('');
  });

  // Encode URI component
  Handlebars.registerHelper('encodeURIComponent', function(str) {
    return encodeURIComponent(str || '');
  });

  // Current year
  Handlebars.registerHelper('currentYear', function() {
    return new Date().getFullYear();
  });

  console.log(chalk.green('✓ Handlebars helpers registered'));
}

// Load templates
async function loadTemplates() {
  const templates = {};
  
  // Load partials
  const partialFiles = await fs.readdir(CONFIG.partialsDir);
  for (const file of partialFiles) {
    if (file.endsWith('.hbs')) {
      const name = path.basename(file, '.hbs');
      const content = await fs.readFile(path.join(CONFIG.partialsDir, file), 'utf-8');
      Handlebars.registerPartial(name, content);
    }
  }
  console.log(chalk.green(`✓ Loaded ${partialFiles.length} partials`));

  // Load page templates
  const pageFiles = await fs.readdir(CONFIG.pagesDir);
  for (const file of pageFiles) {
    if (file.endsWith('.hbs')) {
      const name = path.basename(file, '.hbs');
      const content = await fs.readFile(path.join(CONFIG.pagesDir, file), 'utf-8');
      templates[name] = Handlebars.compile(content);
    }
  }
  console.log(chalk.green(`✓ Loaded ${pageFiles.length} page templates`));

  return templates;
}

// Generate structured data for SEO
function generateStructuredData(type, data, siteSettings) {
  const baseUrl = siteSettings.siteUrl || 'https://sarkarisewayojan.com';
  
  const schemas = {
    website: {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: siteSettings.siteName,
      url: baseUrl,
      potentialAction: {
        '@type': 'SearchAction',
        target: `${baseUrl}/search?q={search_term_string}`,
        'query-input': 'required name=search_term_string'
      }
    },
    jobPosting: (job) => ({
      '@context': 'https://schema.org',
      '@type': 'JobPosting',
      title: job.title,
      description: job.description,
      datePosted: job.date,
      hiringOrganization: {
        '@type': 'Organization',
        name: job.organization || siteSettings.siteName
      },
      jobLocation: {
        '@type': 'Place',
        address: {
          '@type': 'PostalAddress',
          addressCountry: 'IN'
        }
      },
      url: `${baseUrl}/jobs/${job.slug}.html`
    }),
    article: (item, itemType) => ({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: item.title,
      description: item.description,
      datePublished: item.date,
      dateModified: item.updatedAt || item.date,
      author: {
        '@type': 'Organization',
        name: siteSettings.siteName
      },
      publisher: {
        '@type': 'Organization',
        name: siteSettings.siteName,
        logo: {
          '@type': 'ImageObject',
          url: siteSettings.logo || `${baseUrl}/logo.png`
        }
      },
      url: `${baseUrl}/${itemType}/${item.slug}.html`
    }),
    breadcrumb: (items) => ({
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: items.map((item, index) => ({
        '@type': 'ListItem',
        position: index + 1,
        name: item.name,
        item: item.url
      }))
    })
  };

  if (typeof schemas[type] === 'function') {
    return JSON.stringify(schemas[type](data), null, 2);
  }
  return JSON.stringify(schemas[type] || {}, null, 2);
}

// Clean public directory
async function cleanPublicDir() {
  console.log(chalk.blue('Cleaning public directory...'));
  
  // Keep CSS and JS directories if they exist
  const keepDirs = ['css', 'js', 'images', 'assets'];
  
  if (await fs.pathExists(CONFIG.publicDir)) {
    const items = await fs.readdir(CONFIG.publicDir);
    for (const item of items) {
      if (!keepDirs.includes(item)) {
        await fs.remove(path.join(CONFIG.publicDir, item));
      }
    }
  } else {
    await fs.ensureDir(CONFIG.publicDir);
  }
  
  // Create necessary subdirectories
  await fs.ensureDir(path.join(CONFIG.publicDir, 'jobs'));
  await fs.ensureDir(path.join(CONFIG.publicDir, 'results'));
  await fs.ensureDir(path.join(CONFIG.publicDir, 'admit-card'));
  await fs.ensureDir(path.join(CONFIG.publicDir, 'category'));
  
  console.log(chalk.green('✓ Public directory cleaned'));
}

// Generate homepage
async function generateHomepage(templates, data) {
  console.log(chalk.blue('Generating homepage...'));
  
  const { jobs, results, admitCards, categories, siteSettings, lastUpdated } = data;
  const baseUrl = siteSettings.siteUrl || 'https://sarkarisewayojan.com';
  
  const html = templates['home']({
    title: `${siteSettings.siteName} - ${siteSettings.siteTagline}`,
    description: siteSettings.siteDescription,
    keywords: 'sarkari naukri, government jobs, sarkari result, admit card, latest jobs, sarkari exam',
    ogType: 'website',
    canonicalUrl: baseUrl,
    ogImage: `${baseUrl}/og-image.jpg`,
    isHome: true,
    jobs,
    results,
    admitCards,
    categories,
    siteSettings,
    lastUpdated,
    breadcrumb: [
      { name: 'होम', url: '/' }
    ],
    structuredData: `<script type="application/ld+json">${generateStructuredData('website', null, siteSettings)}</script>`
  });
  
  await fs.writeFile(path.join(CONFIG.publicDir, 'index.html'), html);
  console.log(chalk.green('✓ Homepage generated'));
}

// Generate job detail pages
async function generateJobPages(templates, data) {
  console.log(chalk.blue('Generating job pages...'));
  
  const { jobs, siteSettings } = data;
  const baseUrl = siteSettings.siteUrl || 'https://sarkarisewayojan.com';
  
  for (const job of jobs) {
    // Find related jobs (same category, excluding current)
    const relatedJobs = jobs
      .filter(j => j.category === job.category && j.id !== job.id)
      .slice(0, 5);
    
    const html = templates['job-detail']({
      title: `${job.title} - ${siteSettings.siteName}`,
      description: job.metaDescription || job.description?.substring(0, 160),
      keywords: job.keywords || `${job.category}, sarkari naukri, government job`,
      ogType: 'article',
      canonicalUrl: `${baseUrl}/jobs/${job.slug}.html`,
      ogImage: job.ogImage || `${baseUrl}/og-image.jpg`,
      isJobs: true,
      job,
      relatedJobs,
      latestJobs: jobs.slice(0, 5),
      categories: data.categories,
      siteSettings,
      lastUpdated: data.lastUpdated,
      breadcrumb: [
        { name: 'होम', url: '/' },
        { name: 'लेटेस्ट जॉब्स', url: '/latest-jobs.html' },
        { name: job.title, url: `/jobs/${job.slug}.html` }
      ],
      structuredData: `<script type="application/ld+json">${generateStructuredData('jobPosting', job, siteSettings)}</script>`
    });
    
    await fs.writeFile(path.join(CONFIG.publicDir, 'jobs', `${job.slug}.html`), html);
  }
  
  console.log(chalk.green(`✓ Generated ${jobs.length} job pages`));
}

// Generate result detail pages
async function generateResultPages(templates, data) {
  console.log(chalk.blue('Generating result pages...'));
  
  const { results, siteSettings } = data;
  const baseUrl = siteSettings.siteUrl || 'https://sarkarisewayojan.com';
  
  for (const result of results) {
    // Find related results (same category, excluding current)
    const relatedResults = results
      .filter(r => r.category === result.category && r.id !== result.id)
      .slice(0, 5);
    
    const html = templates['result-detail']({
      title: `${result.title} - ${siteSettings.siteName}`,
      description: result.metaDescription || result.description?.substring(0, 160),
      keywords: result.keywords || `${result.category}, sarkari result, exam result`,
      ogType: 'article',
      canonicalUrl: `${baseUrl}/results/${result.slug}.html`,
      ogImage: result.ogImage || `${baseUrl}/og-image.jpg`,
      isResults: true,
      result,
      relatedResults,
      latestResults: results.slice(0, 5),
      categories: data.categories,
      siteSettings,
      lastUpdated: data.lastUpdated,
      breadcrumb: [
        { name: 'होम', url: '/' },
        { name: 'रिजल्ट्स', url: '/results.html' },
        { name: result.title, url: `/results/${result.slug}.html` }
      ],
      structuredData: `<script type="application/ld+json">${generateStructuredData('article', result, siteSettings)}</script>`
    });
    
    await fs.writeFile(path.join(CONFIG.publicDir, 'results', `${result.slug}.html`), html);
  }
  
  console.log(chalk.green(`✓ Generated ${results.length} result pages`));
}

// Generate admit card detail pages
async function generateAdmitCardPages(templates, data) {
  console.log(chalk.blue('Generating admit card pages...'));
  
  const { admitCards, siteSettings } = data;
  const baseUrl = siteSettings.siteUrl || 'https://sarkarisewayojan.com';
  
  for (const admitCard of admitCards) {
    // Find related admit cards (same category, excluding current)
    const relatedAdmitCards = admitCards
      .filter(a => a.category === admitCard.category && a.id !== admitCard.id)
      .slice(0, 5);
    
    const html = templates['admit-card-detail']({
      title: `${admitCard.title} - ${siteSettings.siteName}`,
      description: admitCard.metaDescription || admitCard.description?.substring(0, 160),
      keywords: admitCard.keywords || `${admitCard.category}, admit card, hall ticket`,
      ogType: 'article',
      canonicalUrl: `${baseUrl}/admit-card/${admitCard.slug}.html`,
      ogImage: admitCard.ogImage || `${baseUrl}/og-image.jpg`,
      isAdmitCards: true,
      admitCard,
      relatedAdmitCards,
      latestAdmitCards: admitCards.slice(0, 5),
      categories: data.categories,
      siteSettings,
      lastUpdated: data.lastUpdated,
      breadcrumb: [
        { name: 'होम', url: '/' },
        { name: 'एडमिट कार्ड', url: '/admit-card.html' },
        { name: admitCard.title, url: `/admit-card/${admitCard.slug}.html` }
      ],
      structuredData: `<script type="application/ld+json">${generateStructuredData('article', admitCard, siteSettings)}</script>`
    });
    
    await fs.writeFile(path.join(CONFIG.publicDir, 'admit-card', `${admitCard.slug}.html`), html);
  }
  
  console.log(chalk.green(`✓ Generated ${admitCards.length} admit card pages`));
}

// Generate listing pages
async function generateListingPages(templates, data) {
  console.log(chalk.blue('Generating listing pages...'));
  
  const { jobs, results, admitCards, categories, siteSettings } = data;
  const baseUrl = siteSettings.siteUrl || 'https://sarkarisewayojan.com';
  
  // Jobs listing page
  const jobsHtml = templates['listing']({
    title: `लेटेस्ट सरकारी नौकरियां - ${siteSettings.siteName}`,
    description: 'सभी नवीनतम सरकारी नौकरियों की जानकारी - केंद्रीय और राज्य सरकार की नौकरियां',
    keywords: 'sarkari naukri, latest jobs, government jobs, sarkari exam',
    ogType: 'website',
    canonicalUrl: `${baseUrl}/latest-jobs.html`,
    ogImage: `${baseUrl}/og-image.jpg`,
    isJobs: true,
    pageTitle: 'लेटेस्ट सरकारी नौकरियां',
    pageDescription: 'सभी नवीनतम सरकारी नौकरियों की जानकारी यहां उपलब्ध है',
    items: jobs,
    type: 'jobs',
    categories,
    latestResults: results.slice(0, 5),
    latestAdmitCards: admitCards.slice(0, 5),
    siteSettings,
    lastUpdated: data.lastUpdated,
    breadcrumb: [
      { name: 'होम', url: '/' },
      { name: 'लेटेस्ट जॉब्स', url: '/latest-jobs.html' }
    ],
    structuredData: ''
  });
  await fs.writeFile(path.join(CONFIG.publicDir, 'latest-jobs.html'), jobsHtml);
  console.log(chalk.green('✓ Jobs listing page generated'));
  
  // Results listing page
  const resultsHtml = templates['listing']({
    title: `हाल के रिजल्ट्स - ${siteSettings.siteName}`,
    description: 'सभी हाल के परीक्षा परिणाम - सरकारी नौकरी परीक्षा के रिजल्ट्स',
    keywords: 'sarkari result, exam result, government job result',
    ogType: 'website',
    canonicalUrl: `${baseUrl}/results.html`,
    ogImage: `${baseUrl}/og-image.jpg`,
    isResults: true,
    pageTitle: 'हाल के रिजल्ट्स',
    pageDescription: 'सभी हाल के परीक्षा परिणाम यहां उपलब्ध हैं',
    items: results,
    type: 'results',
    categories,
    latestJobs: jobs.slice(0, 5),
    latestAdmitCards: admitCards.slice(0, 5),
    siteSettings,
    lastUpdated: data.lastUpdated,
    breadcrumb: [
      { name: 'होम', url: '/' },
      { name: 'रिजल्ट्स', url: '/results.html' }
    ],
    structuredData: ''
  });
  await fs.writeFile(path.join(CONFIG.publicDir, 'results.html'), resultsHtml);
  console.log(chalk.green('✓ Results listing page generated'));
  
  // Admit cards listing page
  const admitCardsHtml = templates['listing']({
    title: `एडमिट कार्ड - ${siteSettings.siteName}`,
    description: 'सभी नवीनतम एडमिट कार्ड - परीक्षा हॉल टिकट डाउनलोड करें',
    keywords: 'admit card, hall ticket, exam admit card, sarkari exam',
    ogType: 'website',
    canonicalUrl: `${baseUrl}/admit-card.html`,
    ogImage: `${baseUrl}/og-image.jpg`,
    isAdmitCards: true,
    pageTitle: 'एडमिट कार्ड',
    pageDescription: 'सभी नवीनतम एडमिट कार्ड यहां उपलब्ध हैं',
    items: admitCards,
    type: 'admit-card',
    categories,
    latestJobs: jobs.slice(0, 5),
    latestResults: results.slice(0, 5),
    siteSettings,
    lastUpdated: data.lastUpdated,
    breadcrumb: [
      { name: 'होम', url: '/' },
      { name: 'एडमिट कार्ड', url: '/admit-card.html' }
    ],
    structuredData: ''
  });
  await fs.writeFile(path.join(CONFIG.publicDir, 'admit-card.html'), admitCardsHtml);
  console.log(chalk.green('✓ Admit cards listing page generated'));
}

// Generate static assets (CSS, JS)
async function generateStaticAssets() {
  console.log(chalk.blue('Generating static assets...'));
  
  // Create CSS directory if not exists
  const cssDir = path.join(CONFIG.publicDir, 'css');
  await fs.ensureDir(cssDir);
  
  // Create JS directory if not exists
  const jsDir = path.join(CONFIG.publicDir, 'js');
  await fs.ensureDir(jsDir);
  
  // Check if main.css exists, if not create a basic one
  const mainCssPath = path.join(cssDir, 'main.css');
  if (!await fs.pathExists(mainCssPath)) {
    // CSS will be copied from existing project or created separately
    console.log(chalk.yellow('⚠ main.css not found - please copy from existing project'));
  }
  
  // Check if main.js exists
  const mainJsPath = path.join(jsDir, 'main.js');
  if (!await fs.pathExists(mainJsPath)) {
    console.log(chalk.yellow('⚠ main.js not found - please copy from existing project'));
  }
  
  console.log(chalk.green('✓ Static assets checked'));
}

// Generate sitemap.xml
async function generateSitemap(data) {
  console.log(chalk.blue('Generating sitemap.xml...'));
  
  const { jobs, results, admitCards, categories, siteSettings } = data;
  const baseUrl = siteSettings.siteUrl || 'https://sarkarisewayojan.com';
  
  let sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${baseUrl}/latest-jobs.html</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${baseUrl}/results.html</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${baseUrl}/admit-card.html</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
`;
  
  // Add job pages
  for (const job of jobs) {
    sitemap += `  <url>
    <loc>${baseUrl}/jobs/${job.slug}.html</loc>
    <lastmod>${new Date(job.updatedAt || job.date).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
`;
  }
  
  // Add result pages
  for (const result of results) {
    sitemap += `  <url>
    <loc>${baseUrl}/results/${result.slug}.html</loc>
    <lastmod>${new Date(result.updatedAt || result.date).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
`;
  }
  
  // Add admit card pages
  for (const admitCard of admitCards) {
    sitemap += `  <url>
    <loc>${baseUrl}/admit-card/${admitCard.slug}.html</loc>
    <lastmod>${new Date(admitCard.updatedAt || admitCard.date).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
`;
  }
  
  // Add category pages
  for (const category of categories) {
    sitemap += `  <url>
    <loc>${baseUrl}/category/${category.slug}.html</loc>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
`;
  }
  
  sitemap += '</urlset>';
  
  await fs.writeFile(path.join(CONFIG.publicDir, 'sitemap.xml'), sitemap);
  console.log(chalk.green('✓ Sitemap generated'));
}

// Generate robots.txt
async function generateRobotsTxt(siteSettings) {
  console.log(chalk.blue('Generating robots.txt...'));
  
  const baseUrl = siteSettings.siteUrl || 'https://sarkarisewayojan.com';
  
  const robots = `User-agent: *
Allow: /

Sitemap: ${baseUrl}/sitemap.xml
`;
  
  await fs.writeFile(path.join(CONFIG.publicDir, 'robots.txt'), robots);
  console.log(chalk.green('✓ robots.txt generated'));
}

// Main generation function
async function generate() {
  console.log(chalk.cyan('========================================'));
  console.log(chalk.cyan('  Sarkari Sewayojan - Static Generator'));
  console.log(chalk.cyan('========================================\n'));
  
  const startTime = Date.now();
  
  try {
    // Initialize Firebase
    const { initializeFirebase } = require('../src/config/firebase-admin');
    initializeFirebase();
    
    // Register helpers
    registerHelpers();
    
    // Load templates
    const templates = await loadTemplates();
    
    // Clean public directory
    await cleanPublicDir();
    
    // Fetch all data
    console.log(chalk.blue('\nFetching data from Firestore...'));
    const dataFetcher = new DataFetcher();
    const data = await dataFetcher.fetchAllData();
    console.log(chalk.green(`✓ Data fetched successfully`));
    
    // Generate pages
    console.log(chalk.blue('\nGenerating pages...'));
    await generateHomepage(templates, data);
    await generateJobPages(templates, data);
    await generateResultPages(templates, data);
    await generateAdmitCardPages(templates, data);
    await generateListingPages(templates, data);
    
    // Generate static assets
    await generateStaticAssets();
    
    // Generate SEO files
    await generateSitemap(data);
    await generateRobotsTxt(data.siteSettings);
    
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    
    console.log(chalk.cyan('\n========================================'));
    console.log(chalk.green(`  Generation Complete! (${duration}s)`));
    console.log(chalk.cyan('========================================'));
    console.log(chalk.white(`\nTotal pages generated:`));
    console.log(chalk.white(`  - Jobs: ${data.jobs.length}`));
    console.log(chalk.white(`  - Results: ${data.results.length}`));
    console.log(chalk.white(`  - Admit Cards: ${data.admitCards.length}`));
    console.log(chalk.white(`  - Listing pages: 3`));
    console.log(chalk.white(`  - Homepage: 1`));
    console.log(chalk.cyan(`\nOutput directory: ${CONFIG.publicDir}`));
    
    return {
      success: true,
      stats: {
        jobs: data.jobs.length,
        results: data.results.length,
        admitCards: data.admitCards.length,
        duration
      }
    };
    
  } catch (error) {
    console.error(chalk.red('\n✗ Generation failed:'));
    console.error(chalk.red(error.message));
    console.error(error.stack);
    
    return {
      success: false,
      error: error.message
    };
  }
}

// Run if called directly
if (require.main === module) {
  generate().then(result => {
    process.exit(result.success ? 0 : 1);
  });
}

module.exports = generate;
