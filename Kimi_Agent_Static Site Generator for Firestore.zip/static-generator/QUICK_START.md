# Quick Start Guide

## 5 मिनट में सेटअप करें

### चरण 1: फाइल्स कॉपी करें (1 मिनट)

```bash
# इस static-generator फोल्डर को अपनी वेबसाइट के root में कॉपी करें
cp -r static-generator/* /path/to/your/website/
```

### चरण 2: Firebase Service Account (2 मिनट)

1. [Firebase Console](https://console.firebase.google.com) खोलें
2. अपना प्रोजेक्ट सेलेक्ट करें
3. ⚙️ Project Settings → Service Accounts
4. "Generate New Private Key" पर क्लिक करें
5. डाउनलोड की गई फाइल को `serviceAccountKey.json` के नाम से सेव करें

### चरण 3: इंस्टॉल और टेस्ट (2 मिनट)

```bash
cd /path/to/your/website

# डिपेंडेंसी इंस्टॉल करें
npm install

# टेस्ट जनरेशन
npm run generate

# लोकल प्रीव्यू
npm run serve
```

बस! अब `http://localhost:3000` पर आपकी स्टैटिक वेबसाइट देखें।

## एडमिन पैनल में "Publish" बटन जोड़ें

### React Component:

```jsx
import React, { useState } from 'react';

function PublishButton() {
  const [loading, setLoading] = useState(false);

  const publish = async () => {
    setLoading(true);
    try {
      // Firebase Callable Function
      const fn = firebase.functions().httpsCallable('triggerRegeneration');
      await fn();
      alert('वेबसाइट पब्लिश हो गई!');
    } catch (e) {
      alert('एरर: ' + e.message);
    }
    setLoading(false);
  };

  return (
    <button onClick={publish} disabled={loading}>
      {loading ? 'पब्लिश हो रही है...' : '🚀 Publish Website'}
    </button>
  );
}
```

## कमांड्स रेफरेंस

| कमांड | क्या करता है |
|-------|-------------|
| `npm run generate` | स्टैटिक HTML पेज बनाएं |
| `npm run publish` | GitHub पर भेजें |
| `npm run deploy` | जनरेट + पब्लिश |
| `npm run serve` | लोकल प्रीव्यू |

## फाइल स्ट्रक्चर

```
आपकी-वेबसाइट/
├── scripts/          # जनरेटर स्क्रिप्ट्स
├── templates/        # HTML टेम्पलेट्स
├── functions/        # Firebase Functions
├── public/           # जनरेटेड HTML (यहाँ output आएगा)
│   ├── jobs/         # जॉब पेजेज
│   ├── results/      # रिजल्ट पेजेज
│   ├── admit-card/   # एडमिट कार्ड पेजेज
│   └── index.html    # होमपेज
└── serviceAccountKey.json  # Firebase credentials
```

## जनरेटेड पेजेज

जब आप `npm run generate` चलाएंगे, तो ये पेज बनेंगे:

```
public/
├── index.html                    # होमपेज
├── latest-jobs.html              # सभी जॉब्स की लिस्ट
├── results.html                  # सभी रिजल्ट्स की लिस्ट
├── admit-card.html               # सभी एडमिट कार्ड की लिस्ट
├── jobs/
│   ├── ssc-gd-2026.html         # हर जॉब का अलग पेज
│   ├── up-police-constable.html
│   └── ...
├── results/
│   ├── ssc-cgl-2025-result.html # हर रिजल्ट का अलग पेज
│   └── ...
├── admit-card/
│   ├── ssc-cgl-admit-card.html  # हर एडमिट कार्ड का अलग पेज
│   └── ...
├── sitemap.xml                   # SEO के लिए
└── robots.txt                    # SEO के लिए
```

## जरूरी नोट्स

1. **serviceAccountKey.json** को कभी GitHub पर push न करें
2. `public/` folder में मैन्युअली changes न करें (generate से overwrite हो जाएंगे)
3. बड़ी images को GitHub पर push न करें

## मदद चाहिए?

1. `README.md` पढ़ें - पूरी डॉक्यूमेंटेशन
2. `INTEGRATION_GUIDE.md` पढ़ें - मौजूदा वेबसाइट में इंटीग्रेट करना
3. `HINDI_README.md` पढ़ें - हिंदी में पूरी जानकारी

---

**Ready!** 🎉
