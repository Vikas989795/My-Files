# सरकारी सेवायोजन - स्टैटिक साइट जनरेटर

## 📋 परिचय

यह सिस्टम आपकी वेबसाइट को पूरी तरह से स्टैटिक HTML में बदल देता है। इसका मतलब है कि जब कोई यूजर आपकी वेबसाइट पर आएगा, तो उसके ब्राउजर से Firebase को कोई रिक्वेस्ट नहीं जाएगी। सब कुछ पहले से बने HTML पेज से आएगा।

## 🎯 फायदे

1. **Zero Firebase Reads** - यूजर के ब्राउजर से Firebase को कोई कॉल नहीं
2. **Fast Loading** - पेज तुरंत खुलेंगे
3. **SEO Friendly** - Google में अच्छी रैंकिंग
4. **No CORS Issues** - कोई CORS एरर नहीं
5. **Cost Effective** - Firebase का बिल कम आएगा

## 📁 फाइल स्ट्रक्चर

```
static-generator/
├── scripts/
│   ├── generate.js          # मुख्य जनरेटर स्क्रिप्ट
│   ├── publish.js           # GitHub पर भेजने के लिए
│   └── admin-publish.js     # एडमिन पैनल के लिए
├── templates/               # HTML टेम्पलेट्स
│   ├── partials/            # हेडर, फुटर आदि
│   └── pages/               # पेज टेम्पलेट्स
├── src/
│   ├── config/              # Firebase कॉन्फिग
│   └── utils/               # हेल्पर फंक्शन्स
├── functions/               # Firebase Cloud Functions
├── public/                  # जनरेटेड HTML फाइल्स
├── package.json
└── vercel.json
```

## 🚀 इंस्टॉलेशन

### चरण 1: फाइल्स कॉपी करें

इस `static-generator` फोल्डर को अपनी वेबसाइट के मुख्य फोल्डर में कॉपी करें।

### चरण 2: डिपेंडेंसी इंस्टॉल करें

```bash
cd static-generator
npm install
```

### चरण 3: Firebase सेटअप

1. Firebase Console खोलें
2. Project Settings → Service Accounts पर जाएं
3. "Generate New Private Key" पर क्लिक करें
4. डाउनलोड की गई फाइल को `serviceAccountKey.json` के नाम से सेव करें

### चरण 4: टेस्ट करें

```bash
npm run generate
```

## 📝 उपयोग

### स्टैटिक पेज जनरेट करें

```bash
npm run generate
```

यह कमांड:
1. Firestore से सारा डेटा लेगा
2. HTML पेज बनाएगा
3. `public/` फोल्डर में सेव करेगा

### GitHub पर भेजें

```bash
npm run publish
```

### एक साथ जनरेट और पब्लिश

```bash
npm run deploy
```

## 🔥 Firestore कलेक्शन्स

### Jobs Collection

```javascript
{
  title: "SSC GD Constable 2026",
  description: "पूरी जानकारी...",
  slug: "ssc-gd-constable-2026",
  date: Timestamp,
  category: "Defence",
  content: "HTML content...",
  applyLink: "https://...",
  officialWebsite: "https://...",
  status: "active"
}
```

### Results Collection

```javascript
{
  title: "SSC CGL 2025 Result",
  description: "रिजल्ट जानकारी...",
  slug: "ssc-cgl-2025-result",
  date: Timestamp,
  category: "SSC",
  resultLink: "https://...",
  status: "active"
}
```

### AdmitCards Collection

```javascript
{
  title: "SSC CGL Admit Card 2025",
  description: "एडमिट कार्ड जानकारी...",
  slug: "ssc-cgl-admit-card-2025",
  date: Timestamp,
  category: "SSC",
  examDate: "15/03/2025",
  downloadLink: "https://...",
  status: "active"
}
```

## 🔄 ऑटो-रीजनरेशन (Cloud Functions)

### सेटअप

```bash
cd functions
npm install
firebase deploy --only functions
```

### कैसे काम करता है

जब भी आप Firestore में कोई बदलाव करते हैं:
- नया डॉक्यूमेंट बनाएं → ऑटोमैटिक ट्रिगर
- अपडेट करें → ऑटोमैटिक ट्रिगर
- डिलीट करें → ऑटोमैटिक ट्रिगर

## 📤 डिप्लॉयमेंट

### Vercel पर

```bash
vercel --prod
```

### GitHub + Vercel ऑटो-डिप्लॉय

1. GitHub repository कनेक्ट करें
2. Vercel में प्रोजेक्ट इंपोर्ट करें
3. Build Command: `npm run generate`
4. Output Directory: `public`

## 🎨 कस्टमाइजेशन

### रंग बदलें

`public/css/main.css` में:

```css
:root {
  --primary-color: #2563eb;    /* अपना रंग */
  --secondary-color: #10b981;  /* अपना रंग */
}
```

### टेम्पलेट बदलें

`templates/` फोल्डर में `.hbs` फाइल्स एडिट करें।

## 📊 SEO फीचर्स

- ✅ Dynamic `<title>` और `<meta description>`
- ✅ Open Graph tags
- ✅ Twitter Card tags
- ✅ Structured Data (JSON-LD)
- ✅ Sitemap.xml
- ✅ robots.txt
- ✅ Canonical URLs

## 🛡️ सुरक्षा

- Service Account Key को कभी GitHub पर push न करें
- `.env` फाइल को कभी GitHub पर push न करें
- ये फाइल्स पहले से `.gitignore` में हैं

## 🐛 समस्या निवारण

### समस्या 1: "Firebase service account not found"

**हल:**
```bash
# चेक करें
ls serviceAccountKey.json

# या environment variable सेट करें
export FIREBASE_SERVICE_ACCOUNT='{"type":"service_account",...}'
```

### समस्या 2: "Cannot find module"

**हल:**
```bash
npm install
```

### समस्या 3: जनरेशन फेल

**हल:**
```bash
# साफ करें
rm -rf public/jobs public/results public/admit-card

# फिर से जनरेट करें
npm run generate
```

## 📞 सहायता

किसी भी समस्या के लिए:
1. लॉग्स चेक करें: `npm run generate 2>&1 | tee logs.txt`
2. Firebase Console में एरर्स चेक करें
3. README.md पढ़ें

## 📝 नोट्स

### ✅ करें:
- रेगुलर टेस्टिंग करें
- बैकअप रखें Firestore डेटा का
- `npm run generate` से पहले टेस्ट करें

### ❌ न करें:
- `public/` फोल्डर में मैन्युअली फाइल्स एडिट न करें
- बड़ी इमेजेज को रेपो में add न करें
- Service Account Key को expose न करें

## 🎯 काम कैसे करता है

### डेटा फ्लो:

```
एडमिन पैनल → Firestore → जनरेट स्क्रिप्ट → स्टैटिक HTML → GitHub → Vercel
```

### यूजर रिक्वेस्ट:

```
यूजर → Vercel CDN → स्टैटिक HTML (Firebase कॉल नहीं!)
```

## 📄 लाइसेंस

MIT License

---

**तैयार है!** 🚀

अब आपकी वेबसाइट पूरी तरह से स्टैटिक होगी और जीरो Firebase रीड्स के साथ काम करेगी!
