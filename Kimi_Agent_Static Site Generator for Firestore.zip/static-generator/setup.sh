#!/bin/bash

# Sarkari Sewayojan - Static Generator Setup Script
# This script helps you set up the static site generator quickly

echo "========================================"
echo "  Sarkari Sewayojan - Setup Script"
echo "========================================"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}✗ Node.js is not installed${NC}"
    echo "Please install Node.js 18 or higher: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}✗ Node.js version 18 or higher required${NC}"
    echo "Current version: $(node -v)"
    exit 1
fi

echo -e "${GREEN}✓ Node.js $(node -v) found${NC}"

# Install dependencies
echo ""
echo "Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Failed to install dependencies${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Dependencies installed${NC}"

# Check for service account key
echo ""
if [ ! -f "serviceAccountKey.json" ]; then
    echo -e "${YELLOW}⚠ serviceAccountKey.json not found${NC}"
    echo ""
    echo "Please follow these steps:"
    echo "1. Go to Firebase Console → Project Settings → Service Accounts"
    echo "2. Click 'Generate New Private Key'"
    echo "3. Save the file as 'serviceAccountKey.json' in this directory"
    echo ""
    read -p "Press Enter when you have placed the file..."
    
    if [ ! -f "serviceAccountKey.json" ]; then
        echo -e "${RED}✗ serviceAccountKey.json still not found${NC}"
        echo "Setup cannot continue without Firebase credentials."
        exit 1
    fi
fi

echo -e "${GREEN}✓ serviceAccountKey.json found${NC}"

# Create .env file
echo ""
if [ ! -f ".env" ]; then
    echo "Creating .env file..."
    cp .env.example .env
    echo -e "${GREEN}✓ .env file created${NC}"
    echo -e "${YELLOW}⚠ Please edit .env file with your settings${NC}"
else
    echo -e "${GREEN}✓ .env file already exists${NC}"
fi

# Create necessary directories
echo ""
echo "Creating directories..."
mkdir -p public/jobs public/results public/admit-card public/category public/css public/js
echo -e "${GREEN}✓ Directories created${NC}"

# Test generation
echo ""
echo "Testing static site generation..."
node scripts/generate.js

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Generation test failed${NC}"
    echo "Please check the error messages above."
    exit 1
fi

echo -e "${GREEN}✓ Generation test successful${NC}"

# Setup complete
echo ""
echo "========================================"
echo -e "${GREEN}  Setup Complete!${NC}"
echo "========================================"
echo ""
echo "Next steps:"
echo ""
echo "1. Test locally:"
echo "   npm run serve"
echo ""
echo "2. Generate static files:"
echo "   npm run generate"
echo ""
echo "3. Publish to GitHub:"
echo "   npm run publish"
echo ""
echo "4. Deploy to Vercel:"
echo "   vercel --prod"
echo ""
echo "For more information, see:"
echo "  - README.md"
echo "  - INTEGRATION_GUIDE.md"
echo ""
