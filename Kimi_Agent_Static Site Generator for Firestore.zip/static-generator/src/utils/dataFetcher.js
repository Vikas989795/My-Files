/**
 * Data Fetcher Module
 * Fetches all data from Firebase Firestore for static generation
 */

const { getFirestore } = require('../config/firebase-admin');

class DataFetcher {
  constructor() {
    this.db = getFirestore();
  }

  /**
   * Fetch all jobs from Firestore
   */
  async fetchJobs() {
    try {
      console.log('Fetching jobs from Firestore...');
      const snapshot = await this.db.collection('jobs')
        .orderBy('date', 'desc')
        .get();
      
      const jobs = [];
      snapshot.forEach(doc => {
        const data = doc.data();
        jobs.push({
          id: doc.id,
          ...data,
          // Ensure required fields
          title: data.title || 'Untitled Job',
          description: data.description || '',
          slug: data.slug || this.generateSlug(data.title),
          date: data.date ? data.date.toDate().toISOString() : new Date().toISOString(),
          category: data.category || 'General',
          // SEO fields
          metaDescription: data.metaDescription || data.description?.substring(0, 160) || '',
          keywords: data.keywords || '',
          // Content fields
          content: data.content || data.description || '',
          eligibility: data.eligibility || '',
          importantDates: data.importantDates || [],
          applicationFee: data.applicationFee || '',
          vacancyDetails: data.vacancyDetails || '',
          howToApply: data.howToApply || '',
          officialWebsite: data.officialWebsite || '',
          applyLink: data.applyLink || '',
          notificationLink: data.notificationLink || '',
          // Status
          status: data.status || 'active',
          createdAt: data.createdAt?.toDate?.() ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
          updatedAt: data.updatedAt?.toDate?.() ? data.updatedAt.toDate().toISOString() : new Date().toISOString()
        });
      });

      console.log(`Fetched ${jobs.length} jobs`);
      return jobs;
    } catch (error) {
      console.error('Error fetching jobs:', error);
      throw error;
    }
  }

  /**
   * Fetch all results from Firestore
   */
  async fetchResults() {
    try {
      console.log('Fetching results from Firestore...');
      const snapshot = await this.db.collection('results')
        .orderBy('date', 'desc')
        .get();
      
      const results = [];
      snapshot.forEach(doc => {
        const data = doc.data();
        results.push({
          id: doc.id,
          ...data,
          title: data.title || 'Untitled Result',
          description: data.description || '',
          slug: data.slug || this.generateSlug(data.title),
          date: data.date ? data.date.toDate().toISOString() : new Date().toISOString(),
          category: data.category || 'General',
          metaDescription: data.metaDescription || data.description?.substring(0, 160) || '',
          keywords: data.keywords || '',
          content: data.content || data.description || '',
          resultLink: data.resultLink || '',
          officialWebsite: data.officialWebsite || '',
          status: data.status || 'active',
          createdAt: data.createdAt?.toDate?.() ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
          updatedAt: data.updatedAt?.toDate?.() ? data.updatedAt.toDate().toISOString() : new Date().toISOString()
        });
      });

      console.log(`Fetched ${results.length} results`);
      return results;
    } catch (error) {
      console.error('Error fetching results:', error);
      throw error;
    }
  }

  /**
   * Fetch all admit cards from Firestore
   */
  async fetchAdmitCards() {
    try {
      console.log('Fetching admit cards from Firestore...');
      const snapshot = await this.db.collection('admitCards')
        .orderBy('date', 'desc')
        .get();
      
      const admitCards = [];
      snapshot.forEach(doc => {
        const data = doc.data();
        admitCards.push({
          id: doc.id,
          ...data,
          title: data.title || 'Untitled Admit Card',
          description: data.description || '',
          slug: data.slug || this.generateSlug(data.title),
          date: data.date ? data.date.toDate().toISOString() : new Date().toISOString(),
          category: data.category || 'General',
          metaDescription: data.metaDescription || data.description?.substring(0, 160) || '',
          keywords: data.keywords || '',
          content: data.content || data.description || '',
          examDate: data.examDate || '',
          admitCardReleaseDate: data.admitCardReleaseDate || '',
          downloadLink: data.downloadLink || '',
          officialWebsite: data.officialWebsite || '',
          status: data.status || 'active',
          createdAt: data.createdAt?.toDate?.() ? data.createdAt.toDate().toISOString() : new Date().toISOString(),
          updatedAt: data.updatedAt?.toDate?.() ? data.updatedAt.toDate().toISOString() : new Date().toISOString()
        });
      });

      console.log(`Fetched ${admitCards.length} admit cards`);
      return admitCards;
    } catch (error) {
      console.error('Error fetching admit cards:', error);
      throw error;
    }
  }

  /**
   * Fetch all categories
   */
  async fetchCategories() {
    try {
      console.log('Fetching categories from Firestore...');
      const snapshot = await this.db.collection('categories')
        .orderBy('name', 'asc')
        .get();
      
      const categories = [];
      snapshot.forEach(doc => {
        const data = doc.data();
        categories.push({
          id: doc.id,
          ...data,
          name: data.name || 'Uncategorized',
          slug: data.slug || this.generateSlug(data.name),
          description: data.description || '',
          icon: data.icon || '',
          order: data.order || 0
        });
      });

      console.log(`Fetched ${categories.length} categories`);
      return categories;
    } catch (error) {
      console.error('Error fetching categories:', error);
      // Return empty array if categories collection doesn't exist
      return [];
    }
  }

  /**
   * Fetch site settings
   */
  async fetchSiteSettings() {
    try {
      console.log('Fetching site settings from Firestore...');
      const doc = await this.db.collection('settings').doc('site').get();
      
      if (doc.exists) {
        const data = doc.data();
        return {
          siteName: data.siteName || 'Sarkari Sewayojan',
          siteTagline: data.siteTagline || 'Latest Government Jobs, Results & Admit Cards',
          siteDescription: data.siteDescription || 'Get latest updates on Government Jobs, Exam Results, and Admit Cards.',
          siteUrl: data.siteUrl || 'https://sarkarisewayojan.com',
          logo: data.logo || '',
          favicon: data.favicon || '',
          contactEmail: data.contactEmail || '',
          contactPhone: data.contactPhone || '',
          socialLinks: data.socialLinks || {},
          analytics: data.analytics || {},
          seo: data.seo || {},
          ...data
        };
      }

      // Return default settings
      return {
        siteName: 'Sarkari Sewayojan',
        siteTagline: 'Latest Government Jobs, Results & Admit Cards',
        siteDescription: 'Get latest updates on Government Jobs, Exam Results, and Admit Cards.',
        siteUrl: 'https://sarkarisewayojan.com',
        logo: '',
        favicon: '',
        contactEmail: '',
        contactPhone: '',
        socialLinks: {},
        analytics: {},
        seo: {}
      };
    } catch (error) {
      console.error('Error fetching site settings:', error);
      return {
        siteName: 'Sarkari Sewayojan',
        siteTagline: 'Latest Government Jobs, Results & Admit Cards',
        siteDescription: 'Get latest updates on Government Jobs, Exam Results, and Admit Cards.',
        siteUrl: 'https://sarkarisewayojan.com'
      };
    }
  }

  /**
   * Fetch all data at once
   */
  async fetchAllData() {
    console.log('Fetching all data from Firestore...');
    
    const [jobs, results, admitCards, categories, siteSettings] = await Promise.all([
      this.fetchJobs(),
      this.fetchResults(),
      this.fetchAdmitCards(),
      this.fetchCategories(),
      this.fetchSiteSettings()
    ]);

    return {
      jobs,
      results,
      admitCards,
      categories,
      siteSettings,
      lastUpdated: new Date().toISOString()
    };
  }

  /**
   * Generate slug from title
   */
  generateSlug(title) {
    if (!title) return 'untitled-' + Date.now();
    return title
      .toString()
      .toLowerCase()
      .trim()
      .replace(/\s+/g, '-')
      .replace(/[^\w\-]+/g, '')
      .replace(/\-\-+/g, '-');
  }

  /**
   * Fetch a single job by slug
   */
  async fetchJobBySlug(slug) {
    try {
      const snapshot = await this.db.collection('jobs')
        .where('slug', '==', slug)
        .limit(1)
        .get();
      
      if (snapshot.empty) return null;
      
      const doc = snapshot.docs[0];
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        date: data.date ? data.date.toDate().toISOString() : new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching job by slug:', error);
      return null;
    }
  }

  /**
   * Fetch a single result by slug
   */
  async fetchResultBySlug(slug) {
    try {
      const snapshot = await this.db.collection('results')
        .where('slug', '==', slug)
        .limit(1)
        .get();
      
      if (snapshot.empty) return null;
      
      const doc = snapshot.docs[0];
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        date: data.date ? data.date.toDate().toISOString() : new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching result by slug:', error);
      return null;
    }
  }

  /**
   * Fetch a single admit card by slug
   */
  async fetchAdmitCardBySlug(slug) {
    try {
      const snapshot = await this.db.collection('admitCards')
        .where('slug', '==', slug)
        .limit(1)
        .get();
      
      if (snapshot.empty) return null;
      
      const doc = snapshot.docs[0];
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        date: data.date ? data.date.toDate().toISOString() : new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching admit card by slug:', error);
      return null;
    }
  }
}

module.exports = DataFetcher;
