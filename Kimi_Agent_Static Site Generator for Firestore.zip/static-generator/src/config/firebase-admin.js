/**
 * Firebase Admin Configuration
 * Backend-only Firebase connection for static site generation
 */

const admin = require('firebase-admin');
const path = require('path');

let app;

function initializeFirebase() {
  if (app) return app;

  try {
    // Check if already initialized
    if (admin.apps.length > 0) {
      app = admin.apps[0];
      return app;
    }

    // Try to load service account from environment variable first
    let serviceAccount;
    
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      try {
        serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
        console.log('Loaded Firebase credentials from environment variable');
      } catch (e) {
        console.error('Failed to parse FIREBASE_SERVICE_ACCOUNT:', e.message);
      }
    }

    // Fallback to service account file
    if (!serviceAccount) {
      const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH || 
        path.join(__dirname, '../../serviceAccountKey.json');
      
      try {
        serviceAccount = require(serviceAccountPath);
        console.log('Loaded Firebase credentials from file:', serviceAccountPath);
      } catch (e) {
        console.error('Failed to load service account file:', e.message);
        throw new Error('Firebase service account not found. Please set FIREBASE_SERVICE_ACCOUNT environment variable or place serviceAccountKey.json in project root.');
      }
    }

    app = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      databaseURL: process.env.FIREBASE_DATABASE_URL || `https://${serviceAccount.project_id}.firebaseio.com`
    });

    console.log('Firebase Admin initialized successfully');
    return app;
  } catch (error) {
    console.error('Firebase initialization error:', error);
    throw error;
  }
}

function getFirestore() {
  const firebase = initializeFirebase();
  return firebase.firestore();
}

function getStorage() {
  const firebase = initializeFirebase();
  return firebase.storage();
}

module.exports = {
  initializeFirebase,
  getFirestore,
  getStorage,
  admin
};
