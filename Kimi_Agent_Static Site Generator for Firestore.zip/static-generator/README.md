# Sarkari Sewayojan - Static Site Generator

पूरी तरह से Static HTML आधारित सरकारी नौकरी वेबसाइट जनरेटर। यह सिस्टम Firebase Firestore से डेटा लेकर पूरी तरह से Static HTML पेज जनरेट करता है, जिससे Frontend से Firebase Reads **ZERO** हो जाते हैं।

## 🎯 Features

- ✅ **Zero Firebase Reads** - Frontend से कोई Firebase API call नहीं
- ✅ **SEO Optimized** - Proper meta tags, structured data, sitemap
- ✅ **Fast Loading** - Pure static HTML, no client-side rendering
- ✅ **Auto Regeneration** - Firestore triggers से automatic update
- ✅ **GitHub Integration** - Automatic commit and push
- ✅ **Vercel Ready** - One-click deployment
- ✅ **Mobile Responsive** - सभी devices पर बेहतर अनुभव
- ✅ **Hindi Language** - पूरी तरह से हिंदी में

## 📁 Project Structure

```
static-generator/
├── scripts/
│   ├── generate.js          # Main static site generator
│   └── publish.js           # GitHub publish script
├── templates/
│   ├── partials/
│   │   ├── head.hbs         # HTML head template
│   │   ├── header.hbs       # Site header
│   │   └── footer.hbs       # Site footer
│   └── pages/
│       ├── home.hbs         # Homepage template
│       ├── job-detail.hbs   # Job detail page
│       ├── result-detail.hbs # Result detail page
│       ├── admit-card-detail.hbs # Admit card page
│       └── listing.hbs      # Listing pages
├── src/
│   ├── config/
│   │   └── firebase-admin.js # Firebase admin config
│   └── utils/
│       └── dataFetcher.js   # Data fetching utilities
├── functions/
│   ├── index.js             # Cloud Functions (triggers)
│   └── package.json
├── public/                  # Generated static files
│   ├── css/
│   ├── js/
│   ├── jobs/
│   ├── results/
│   └── admit-card/
├── package.json
├── vercel.json
└── .env.example
```

## 🚀 Installation

### Step 1: Clone and Install

```bash
cd static-generator
npm install
```

### Step 2: Firebase Setup

1. Firebase Console से Service Account Key डाउनलोड करें:
   - Project Settings → Service Accounts → Generate New Private Key
   - फाइल को `serviceAccountKey.json` के नाम से सेव करें

2. या Environment Variable सेट करें:
```bash
export FIREBASE_SERVICE_ACCOUNT='{"type":"service_account",...}'
```

### Step 3: Environment Configuration

```bash
cp .env.example .env
# .env फाइल में अपनी settings भरें
```

## 📝 Usage

### Static Pages Generate करें

```bash
# सभी pages generate करें
npm run generate

# या
node scripts/generate.js
```

### GitHub पर Publish करें

```bash
npm run publish
```

### एक साथ Generate और Publish

```bash
npm run deploy
```

### Local Preview

```bash
npm run serve
```

## 🔥 Firestore Collections

### Jobs Collection
```javascript
{
  title: "SSC GD Constable 2026",
  description: "Full description...",
  slug: "ssc-gd-constable-2026",
  date: Timestamp,
  category: "Defence",
  content: "HTML content...",
  eligibility: "Eligibility criteria...",
  importantDates: [
    { label: "Start Date", value: "01/01/2026" },
    { label: "Last Date", value: "31/01/2026" }
  ],
  applicationFee: "Fee details...",
  vacancyDetails: "Vacancy info...",
  howToApply: "Application process...",
  applyLink: "https://...",
  notificationLink: "https://...",
  officialWebsite: "https://...",
  status: "active",
  metaDescription: "SEO description...",
  keywords: "ssc, gd, constable"
}
```

### Results Collection
```javascript
{
  title: "SSC CGL 2025 Result",
  description: "Result description...",
  slug: "ssc-cgl-2025-result",
  date: Timestamp,
  category: "SSC",
  content: "Result details...",
  resultLink: "https://...",
  officialWebsite: "https://...",
  examName: "SSC CGL 2025",
  examDate: "15/03/2025",
  status: "active"
}
```

### AdmitCards Collection
```javascript
{
  title: "SSC CGL Admit Card 2025",
  description: "Admit card info...",
  slug: "ssc-cgl-admit-card-2025",
  date: Timestamp,
  category: "SSC",
  content: "Admit card details...",
  examDate: "15/03/2025",
  admitCardReleaseDate: "01/03/2025",
  downloadLink: "https://...",
  officialWebsite: "https://...",
  documentsRequired: "List of documents...",
  instructions: "Important instructions...",
  status: "active"
}
```

## 🔄 Auto-Regeneration (Cloud Functions)

### Setup

```bash
cd functions
npm install
firebase deploy --only functions
```

### Available Triggers

- `onJobCreate` - Job create होने पर
- `onJobUpdate` - Job update होने पर
- `onJobDelete` - Job delete होने पर
- `onResultCreate/Update/Delete` - Results के लिए
- `onAdmitCardCreate/Update/Delete` - Admit Cards के लिए

### Manual Trigger from Admin Panel

```javascript
// Admin panel से call करें
const regenerateSite = firebase.functions().httpsCallable('triggerRegeneration');
regenerateSite().then(result => {
  console.log('Site regenerated:', result.data);
});
```

## 📤 Deployment

### Vercel पर Deploy करें

1. Vercel CLI install करें:
```bash
npm i -g vercel
```

2. Deploy करें:
```bash
vercel --prod
```

### GitHub + Vercel Auto-Deploy

1. GitHub repository connect करें
2. Vercel में project import करें
3. Build Command: `npm run generate`
4. Output Directory: `public`

## 🎨 Customization

### Colors Change करें

`public/css/main.css` में CSS variables edit करें:

```css
:root {
  --primary-color: #2563eb;
  --secondary-color: #10b981;
  --accent-color: #f59e0b;
  /* ... */
}
```

### Templates Modify करें

`templates/` folder में Handlebars (.hbs) files edit करें।

### New Page Add करें

1. `templates/pages/` में new template बनाएं
2. `scripts/generate.js` में generation logic add करें
3. `npm run generate` run करें

## 🔍 SEO Features

- ✅ Dynamic `<title>` and `<meta description>`
- ✅ Open Graph tags
- ✅ Twitter Card tags
- ✅ Structured Data (JSON-LD)
- ✅ Sitemap.xml generation
- ✅ robots.txt generation
- ✅ Canonical URLs
- ✅ Breadcrumb navigation

## 📊 Performance

- **First Contentful Paint**: < 1s
- **Largest Contentful Paint**: < 2s
- **Time to Interactive**: < 2s
- **Cumulative Layout Shift**: < 0.1

## 🛡️ Security Headers

Vercel deployment में ये security headers configured हैं:

- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY
- X-XSS-Protection: 1; mode=block
- Referrer-Policy: strict-origin-when-cross-origin

## 🐛 Troubleshooting

### Generation Fail हो रहा है

```bash
# Firebase credentials check करें
cat serviceAccountKey.json

# Environment variables check करें
env | grep FIREBASE
```

### Pages Generate नहीं हो रहे

```bash
# Public directory clean करें
rm -rf public/jobs public/results public/admit-card

# फिर से generate करें
npm run generate
```

### Git Push Fail हो रहा है

```bash
# Remote URL check करें
git remote -v

# Remote set करें
git remote add origin https://github.com/username/repo.git
```

## 📞 Support

किसी भी issue के लिए:

1. Logs check करें: `npm run generate 2>&1 | tee logs.txt`
2. Firebase Console में errors check करें
3. GitHub Issues में report करें

## 📄 License

MIT License

## 🙏 Credits

Built with ❤️ for Sarkari Sewayojan

---

**Note**: यह system पूरी तरह से static HTML generate करता है। Frontend पर कोई भी Firebase SDK या API call नहीं होता। सारा data build time पर Firestore से fetch होकर static files में convert हो जाता है।
